<?php

use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Psr7\Request;
use Slim\Psr7\Response as ResponseMW;

include_once __DIR__ . "./AccesoDatos.php";
include_once __DIR__ . "./Usuario.php";
include_once __DIR__ . "./Autentificadora.php";

class MW
{
    public function verificarToken(Request $request, RequestHandler $handler): ResponseMW
    {
        $token = $request->getHeader('token')[0];
        $returnJSON = new stdClass();
        $returnJSON->status = 403;
        $verificacion = Autentificadora::VerificarJWT($token);
        $returnJSON->mensaje = $verificacion->mensaje;

        if($verificacion->verificado)
        {
            $returnJSON = json_decode($handler->handle($request)->getBody());
            $returnJSON->status = 200;
        }

        $newResponse = new ResponseMW($returnJSON->status);
        $newResponse->getBody()->write(json_encode($returnJSON));
        return $newResponse->withHeader('Content-Type', 'application/json');
    }
}