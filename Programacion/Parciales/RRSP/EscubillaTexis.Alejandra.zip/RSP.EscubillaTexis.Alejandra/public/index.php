<?php

use Slim\Factory\AppFactory;
use Slim\Routing\RouteCollectorProxy;
use Slim\Views\Twig;
use Slim\Views\TwigMiddleware;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

require __DIR__ . './../vendor/autoload.php';
require_once __DIR__ . './../src/poo/Usuario.php';
require_once __DIR__ . './../src/poo/MW.php';

$app = AppFactory::create();

$app->post('/user', \Usuario::class . ':agregarUno')->add(MW::class . ":verificarToken");

$app->get('/', \Usuario::class . ':mostrarTodos');

$app->group('/login', function (RouteCollectorProxy $group) {
    
    $group->post('', \Usuario::class . ':login');
    
    $group->get('', \Usuario::class . ':verificarJWT');
});

$app->group('/usuarios', function (RouteCollectorProxy $group) {
    
    $group->delete('', \Usuario::class . ':borrarUno');
    
    $group->post('', \Usuario::class . ':modificarUno');

})->add(MW::class . ":verificarToken");

$app->run();
