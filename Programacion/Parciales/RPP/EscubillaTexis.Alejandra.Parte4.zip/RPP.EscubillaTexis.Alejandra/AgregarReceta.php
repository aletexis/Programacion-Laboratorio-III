<?php

    /*AgregarReceta.php: Se recibirán por POST todos los valores: nombre, ingredientes, tipo y foto para registrar una
    receta en la base de datos.
    Verificar la previa existencia de la receta invocando al método Existe. Se le pasará como parámetro el array que
    retorna el método Traer.
    Si la receta ya existe en la base de datos, se retornará un mensaje que indique lo acontecido.
    Si la receta no existe, se invocará al método Agregar. La imagen guardarla en “./recetas/imagenes/”, con el
    nombre formado por el nombre punto tipo punto hora, minutos y segundos del alta (Ejemplo:
    chocotorta.pasteleria.105905.jpg).
    Se retornará un JSON que contendrá: éxito(bool) y mensaje(string) indicando lo acontecido. */

    require "./clases/Receta.php";

    $nombre = isset($_POST["nombre"]) ? $_POST["nombre"] : NULL;
    $ingredientes = isset($_POST["ingredientes"]) ? $_POST["ingredientes"] : NULL;
    $tipo = isset($_POST["tipo"]) ? $_POST["tipo"] : NULL;

    $ubicacion = "./recetas/imagenes/";

    $receta = new Receta("", $nombre,"", $tipo, "");
    $array = $receta->Traer();

    $obj = new stdClass();
    
    if($receta->Existe($array))
    {
        $obj->exito = false;
        $obj->mensaje = "Error! La receta ya existe en la Base de Datos";
    }
    else
    {
        $pathFoto = $ubicacion . $_FILES["foto"]["name"];
        $imagen = strtolower(pathinfo($pathFoto, PATHINFO_EXTENSION));
        $fechaActual = date("h:i:s");
        $fechaActual = str_replace(":", "", $fechaActual);
        $_FILES["foto"]["name"] = $nombre . "." . $tipo . "." . $fechaActual . "." . $imagen;
        $pathFoto = $ubicacion . $_FILES["foto"]["name"];
        move_uploaded_file($_FILES["foto"]["tmp_name"], $pathFoto);
        $newaux = new Receta("", $nombre, $ingredientes, $tipo,$_FILES["foto"]["name"]);
        $flag = $newaux->Agregar();
        
        if($flag)
        {
            $obj->exito = $flag;
            $obj->mensaje = "La receta se agrego exitosamente";
        }
    }

    echo json_encode($jsobjon);
?>