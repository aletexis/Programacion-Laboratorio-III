<?php
    /*ListadoCocineros.php: (GET) Se mostrará el listado de todos los cocineros en formato JSON. */

    require "./clases/Cocinero.php";
    
    $array = Cocinero::traerTodos();
    $json = "";
    $listajson = [];
    
    if($array !== NULL)
    {
        foreach($array as $item)
        {
            array_push($listajson, json_decode($item->ToJSON()));
        }
    }
    echo json_encode($listajson);
?>