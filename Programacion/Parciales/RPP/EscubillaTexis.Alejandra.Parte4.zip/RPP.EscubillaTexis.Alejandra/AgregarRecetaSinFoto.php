<?php
        /*AgregarRecetaSinFoto.php: Se recibe por POST el nombre, los ingredientes y el tipo. Se invocará al método
        Agregar.
        Se retornará un JSON que contendrá: éxito(bool) y mensaje(string) indicando lo acontecido. */

        require "./clases/Receta.php";

        $nombre = isset($_POST["nombre"]) ? $_POST["nombre"] : NULL;
        $ingredientes = isset($_POST["ingredientes"]) ? $_POST["ingredientes"] : NULL;
        $tipo = isset($_POST["tipo"]) ? $_POST["tipo"] : NULL;

        $receta = new Receta("", $nombre, $ingredientes, $tipo);

        $obj = new stdClass();
        $obj->exito = false;
        $obj->mensaje = "Error! No se pudo agregar";

        if($receta->Agregar())
        {
                $obj->exito = true;
                $obj->mensaje = "Se agregó exitosamente";
        }

        echo json_encode($obj);
?>