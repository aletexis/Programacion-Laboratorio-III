<?php

    class Cocinero
    {
        private $especialidad;
        private $email;
        private $clave;

        static $path = "./archivos/cocinero.json";

        function __construct($especialidad, $email, $clave)
        {
            $this->especialidad = $especialidad;
            $this->email = $email;
            $this->clave = $clave;
        }

        public function _getEspecialidad()
        {
            return $this->especialidad;
        }

        public function _setEspecialidad($especialidad)
        {
            $this->especialidad = $especialidad;
        }

        public function _getEmail()
        {
            return $this->email;
        }

        public function _getClave()
        {
            return $this->clave;
        }

        function ToJSON()
        {
            $obj = new stdClass();
            $obj->especialidad = $this->especialidad;
            $obj->email = $this->email;
            $obj->clave = $this->clave;
            return json_encode($obj);
        }

        /*Método de instancia GuardarEnArchivo(), que agregará al cocinero en ./archivos/cocinero.json. Retornará un
        JSON que contendrá: éxito(bool) y mensaje(string) indicando lo acontecido. */
        
        function GuardarEnArchivo()
        {
            $arrayJson = array();
            $obj = new stdClass();
            $obj->exito = false;
            $obj->mensaje = "Error! No se pudo guardar"; 

            if(file_exists(Cocinero::$path)) 
            {
                $archivo = fopen(Cocinero::$path, "r+");
                $leo = fread($archivo, filesize(Cocinero::$path));
                fclose($archivo);
                $arrayJson = json_decode($leo);
                array_push($arrayJson, json_decode($this->ToJSON()));
                $archivo = fopen(Cocinero::$path, "w+");
                $cant = fwrite($archivo, json_encode($arrayJson));
                
                if($cant > 0)
                {
                    $obj->exito = true;
                    $obj->mensaje = "Agregado correctamente";
                }
                fclose($archivo);
            } 
            else 
            {
                $archivo = fopen(Cocinero::$path, "w+");
                array_push($arrayJson, json_decode($this->ToJSON()));
                $cant = fwrite($archivo, json_encode($arrayJson));
                
                if($cant > 0)
                {
                    $obj->exito = true;
                    $obj->mensaje = "Agregado correctamente";
                }
                fclose($archivo);
            }
            return json_encode($obj);
        }

        /*Método de clase TraerTodos(), que retornará un array de objetos de tipo Cocinero. */
        static function TraerTodos()
        {
            $traigoTodos = array();
            $archivo = fopen(Cocinero::$path, "r");
            $archAux = fread($archivo, filesize(Cocinero::$path));
            $traigoTodos = json_decode($archAux, true, 512, JSON_OBJECT_AS_ARRAY);
            fclose($archivo);
            
            $cantidad = count($traigoTodos);
            $array = [];
            
            for($i = 0; $i < $cantidad; $i++)
            {
                $nuevo = new Cocinero($traigoTodos[$i]["especialidad"], $traigoTodos[$i]["email"], $traigoTodos[$i]["clave"]);
                array_push($array, $nuevo);
            }
            return $array;
        }

        /*Método de clase VerificarExistencia($cocinero), que recorrerá el array (invocar a TraerTodos) y retornará un JSON
        que contendrá: existe(bool) y mensaje(string).
        Si el cocinero está registrado (email y clave), retornará true y el mensaje indicará cuantos cocineros están
        registrados con la misma especialidad del cocinero recibido por parámetro. Caso contrario, retornará false, y
        el/los nombres de la/las especialidades más populares (mayor cantidad de apariciones). */
        
        public static function VerificarExistencia($cocinero)
        {
            $obj = new stdClass();
            $obj->existe = false;
            $obj->mensaje = "Error! No se pudo encontrar el cocinero.";

            $arrayCocineros = Cocinero::TraerTodos();
            $cantidadMismaEspecialidad = 0;
            $flag = 0;

            $array = [];
            $contadorEspecialidades = 0;
            $nombreEspecialidadPopular = "";

            foreach($arrayCocineros as $item) 
            {
                if($item->email == $cocinero->email && $item->clave == $cocinero->clave)
                {
                    $obj->existe = true;
                    $flag = 1;
                    
                    foreach($arrayCocineros as $cocinerito) 
                    {
                        if($cocinerito->especialidad == $cocinero->especialidad)
                        {
                            $cantidadMismaEspecialidad++;
                        }
                    }

                    array_push($array, $item->email);
                    $obj->mensaje = $cantidadMismaEspecialidad . " cocineros registrados con la especialidad " . $cocinero->especialidad;
                    break;
                }
            }

            if($flag == 0) 
            {            
                $nombres = array_count_values($array);
                
                foreach($nombres as $i => $item)
                {
                    $contadorEspecialidades = $item;
                    $nombreEspecialidadPopular = $i;

                    if($contadorEspecialidades < $item)
                    {
                        $nombres[$i]->item = $contadorEspecialidades;
                        $nombreEspecialidadPopular = $i;
                    }
                }

                $obj->mensaje = "Cocinero/s mas popular/es: " . $nombreEspecialidadPopular;
            }

            return json_encode($obj);
        }    

    }
?>