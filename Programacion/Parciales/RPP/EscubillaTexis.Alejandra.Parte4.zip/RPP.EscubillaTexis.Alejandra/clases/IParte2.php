<?php

    interface IParte2
    {
        function Existe($array);
        function Modificar();
    }

?>