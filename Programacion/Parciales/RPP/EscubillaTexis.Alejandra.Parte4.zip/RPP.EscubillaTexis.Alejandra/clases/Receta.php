<?php
    require './clases/AccesoDatos.php';
    require './clases/IParte2.php';
    require './clases/IParte3.php';
    require './clases/IParte1.php';
    
    class Receta implements IParte2,IParte3,IParte1
    {
        public $id;
        public $nombre;
        public $ingredientes;
        public $tipo;
        public $pathFoto;

        public function __construct($_id = "", $_nombre, $_ingredientes, $_tipo, $_pathFoto = "")
        {
            $this->id = $_id;
            $this->nombre = $_nombre;
            $this->ingredientes = $_ingredientes;
            $this->tipo = $_tipo;
            $this->pathFoto = $_pathFoto;
        }

        public function ToJSON()
        {
            $obj = new stdClass();
            $obj->id = $this->id;
            $obj->nombre = $this->nombre;
            $obj->ingredientes = $this->ingredientes;
            $obj->tipo = $this->tipo;
            $obj->pathFoto = $this->pathFoto;
            return json_encode($obj);
        }

        /*Agregar: agrega, a partir de la instancia actual, un nuevo registro en la tabla recetas (id, nombre,
        ingredientes, tipo, foto), de la base de datos recetas_bd. Retorna true, si se pudo agregar, false, caso
        contrario. */
        public function Agregar()
        {
            $objBD = AccesoDatos::DameUnObjetoAcceso();
            $consulta = $objBD->RetornarConsulta("INSERT INTO recetas ( nombre, ingredientes, tipo, path_foto)VALUES(?,?,?,?)");
            return $consulta->execute([$this->nombre, $this->ingredientes, $this->tipo, $this->pathFoto]);
        }

        /*Traer: retorna un array de objetos de tipo Receta, recuperados de la base de datos.*/
        public function Traer()
        {
            $lista = [];
            $objBD = AccesoDatos::DameUnObjetoAcceso();
            $consulta = $objBD->RetornarConsulta("SELECT * FROM recetas");
            $consulta->execute();

            while ($fila = $consulta->fetch())
            {
                $nuevo = new Receta($fila[0], $fila[1], $fila[2], $fila[3], $fila[4]);
                array_push($lista, $nuevo);
            }
            return $lista;
        }

        /*Existe: retorna true, si la instancia actual está en el array de objetos de tipo Receta que recibe como
        parámetro (comparar por nombre y tipo). Caso contrario retorna false. */
        function Existe($array)
        {
            $existe = false;
            
            foreach ($array as $item)
            {
                if($this->nombre == $item->nombre && $this->tipo == $item->tipo)
                {
                    $existe = true;
                    break;
                }
            }
            return $existe;
        }

        /*Modificar: Modifica en la base de datos el registro coincidente con la instancia actual (comparar por id).
        Retorna true, si se pudo modificar, false, caso contrario. */
        function Modificar()
        {
            $objBD = AccesoDatos::DameUnObjetoAcceso();
            $consulta = $objBD->RetornarConsulta("UPDATE recetas SET nombre= ?, ingredientes= ?,tipo= ?,path_foto= ? WHERE id=?");
            return $consulta->execute([$this->nombre, $this->ingredientes, $this->tipo, $this->pathFoto,$this->id]);
        }

        /*Eliminar: elimina de la base de datos el registro coincidente con la instancia actual (comparar por nombre
        y tipo). Retorna true, si se pudo eliminar, false, caso contrario. */
        function Eliminar()
        {
            $objBD = AccesoDatos::DameUnObjetoAcceso();
            $consulta = $objBD->RetornarConsulta("DELETE FROM recetas WHERE nombre=? AND tipo=?");
            return $consulta->execute([$this->nombre, $this->tipo]);
        }

        /*GuardarEnArchivo: escribirá en un archivo de texto (recetas_borradas.txt) toda la información de la
        receta más la nueva ubicación de la foto. La foto se moverá al subdirectorio “./recetasBorradas/”, con el
        nombre formado por el id punto nombre punto 'borrado' punto hora, minutos y segundos del borrado
        (Ejemplo: 123.paella.borrado.105905.jpg). */
        function GuardarEnArchivo()
        {
            $nombreArchivo = "./recetas_borradas.txt";
            $archivo = fopen($nombreArchivo, "a+");
            
            if($archivo)
            {
                $pathFoto = $this->pathFoto;
                $fechaActual = date("h:i:s");
                $fechaActual = str_replace(":", "", $fechaActual);
                $pathviejoM = "recetasModificadas/" . $pathFoto;
                $pathviejoI = "recetas/imagenes/" . $pathFoto;
                $imagennombre = strtolower(pathinfo($pathFoto, PATHINFO_EXTENSION));
                
                if(file_exists("./recetasModificadas/" . $pathFoto))
                {
                    rename(chop($pathviejoM), chop("./recetasBorradas/" . $this->id . "." . $this->nombre . "." . "borrado" . "." . $fechaActual . "." . $imagennombre));
                }
                
                if(file_exists("./recetas/imagenes/" . $pathFoto))
                {
                    rename(chop($pathviejoI), chop("./recetasBorradas/" . $this->id . "." . $this->nombre . "." . "borrado" . "." . $fechaActual . "." . $imagennombre));
                }
                
                $this->pathFoto = $this->id . "." . $this->nombre . "." . "borrado" . "." . $fechaActual . "." . $imagennombre;
                fwrite($archivo, $this->id . "-" . $this->nombre . "-" . $this->ingredientes . "-" . $this->tipo . "-" . chop($this->pathFoto) . "\r\n");
                fclose($archivo);
            }
        } 
        
        static function MostrarBorrados()
        {
            $archivo = fopen('./recetas_borradas.txt', "r");
            $datos = array();
            $listaBorrados = array();
            
            if($archivo)
            {
                $archivito = filesize('./recetas_borradas.txt');
                if($archivito != 0)
                {
                    while(!feof($archivo))
                    {
                        $cadena = fgets($archivo);
                        $datos = explode('-', $cadena);
                        if(count($datos) > 2)
                        {
                            $auxBorrada = new Receta($datos[0], $datos[1], $datos[2], $datos[3], $datos[4]);
                            array_push($listaBorrados, $auxBorrada);
                        }
                    }
                }
                fclose($archivo);
            }
            return $listaBorrados;
        }
    } 
?>