<?php

    interface IParte1
    {
        function Agregar();
        function Traer();
    }
?>