<?php

    interface IParte3
    {
        function Eliminar();
        function GuardarEnArchivo();
    }
?>