<?php

    /*VerificarCocinero.php: Se recibe por POST el email y la clave, si coinciden con algún registro del archivo JSON
    (VerificarExistencia), crear una COOKIE nombrada con el email y la especialidad del cocinero, separado con un
    guión bajo (maru_botana@gmail.com_pastelero) que guardará la fecha actual (con horas, minutos y segundos)
    más el retorno del mensaje del método VerificarExistencia.
    Retornar un JSON que contendrá: éxito(bool) y mensaje(string) indicando lo acontecido (agregar el mensaje
    obtenido del método de clase). */
    
    require "./clases/Cocinero.php";

    $email = isset($_POST["email"]) ? $_POST["email"] : NULL;
    $clave = isset($_POST["clave"]) ? $_POST["clave"] : NULL;

    if($email != NULL && $clave != NULL)
    {
        $cocinero = new Cocinero("", $email, $clave);
        $exito = $cocinero->VerificarExistencia($cocinero);
        $decode = json_decode($exito);

        if($decode->exito)
        {
            $obj = new stdClass();
            $obj->exito = false;
            $obj->mensaje = "Error! No se pudo guardar la cookie.";

            $nombreCookie = $cocinero->_getEmail() . "_" . $cocinero->_getEspecialidad();
            $valorCookie = date("d/m/Y - G:i:s") . " - " . $decode->mensaje;

            if(setcookie($nombreCookie, $valorCookie, time()+360))
            {
                $obj->exito = true;
                $obj->mensaje = "Cookie guardada correctamente! ";
                $obj->mensaje .= $decode->mensaje;
            }
        }

        echo json_encode($obj);
    }

?>
