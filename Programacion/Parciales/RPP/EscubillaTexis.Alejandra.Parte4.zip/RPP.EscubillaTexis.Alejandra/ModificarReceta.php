<?php

    /*ModificarReceta.php: Se recibirán por POST los siguientes valores: receta_json (id, nombre, ingredientes, tipo y
    pathFoto, en formato de cadena JSON) y foto (para modificar una receta en la base de datos. Invocar al método
    Modificar.
    Nota: El valor del id, será el id de la receta 'original', mientras que el resto de los valores serán los de la receta
    modificada.
    Si se pudo modificar en la base de datos, la foto modificada se moverá al subdirectorio “./recetasModificadas/”,
    con el nombre formado por el nombre punto tipo punto 'modificado' punto hora, minutos y segundos de la
    modificación (Ejemplo: puchero.bodegon.modificado.105905.jpg).
    Se retornará un JSON que contendrá: éxito(bool) y mensaje(string) indicando lo acontecido. */

    require "./clases/Receta.php";

    $ubicacion = "./recetasModificadas/";
    $ubicaion2 = "./recetas/imagenes/";

    $aux = json_decode($_POST["receta_json"]);
    $pathFoto = $ubicacion . $_FILES["foto"]["name"];
    $fechaActual = date("h:i:s");
    $fechaActual = str_replace(":", "", $fechaActual);
    $imagen = strtolower(pathinfo($pathFoto, PATHINFO_EXTENSION));
    
    $obj = new stdClass();
    $obj->exito = false;
    $obj->mensaje = "Error! No se pudo modificar";

    $aux->foto = $aux->nombre . "." . $aux->tipo . "." . "modificado" . "." . $fechaActual . "." . $imagen;
    $auxnueva = new Receta($aux->id, $aux->nombre, $aux->ingredientes, $aux->tipo, $aux->foto);

    if($auxnueva->Modificar())
    {
        $_FILES["foto"]["name"] = $ubicacion . $auxnueva->nombre . "." . $auxnueva->tipo . "." . "modificado" . "." . $fechaActual . "." . $imagen;
        move_uploaded_file($_FILES["foto"]["tmp_name"], $_FILES["foto"]["name"]);
        $obj->exito = true;
        $obj->mensaje = "Receta modificada exitosamente";
    }

    echo json_encode($obj);
?>
