<?php
    require "./clases/Receta.php";

    $nombre = $_GET["nombre"] ?? NULL;
    $receta = $_POST["receta_json"] ?? NULL;
    $accion = $_POST["accion"] ?? NULL;

    $ubicacion = "./recetasBorradas/";

    $newaux = new Receta("", "", "", "");

    if ($receta == NULL) 
    {
        if ($nombre != NULL) 
        {
            $lista = [];
            $lista = $newaux->Traer();
            $retorno = "La receta no se encuentra en la base de datos";
            
            foreach ($lista as $key) 
            {
                if ($key->nombre == $nombre) 
                {
                    $retorno = "La receta se encuentra en la base de datos";
                    break;
                }
            }
            echo $retorno;
        } 
        else 
        {
            $listaBorrados = Receta::MostrarBorrados();
?>
            <!DOCTYPE html>
            <html lang="en">

            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Document</title>
                <style>
                    table {

                        padding: 20px;
                        margin: 0 auto;
                        width: 900px;
                        text-align: center;
                    }

                    .trpapa {
                        height: 100px;
                    }
                </style>
            </head>

            <body>
                <table>
                    <th>
                        <h4>Listado Eliminado</h4>
                    </th>
                    <tr>
                        <td colspan="4">
                            <hr />
                        </td>
                    </tr>
                    <tr>
                        <th>Nombre</th>
                        <th>ingredientes</th>
                        <th>tipo</th>
                        <th>Foto</th>
                    </tr>
                    <?php foreach ($listaBorrados as $key) { ?>
                        <tr class="trpapa">
                            <td><?php echo $key->nombre ?></td>
                            <td><?php echo $key->ingredientes ?></td>
                            <td><?php echo $key->tipo ?></td>
                            <?php
                            $flag = false;
                            
                            if ($key->pathFoto == "") 
                            {
                                echo '<td>SinFoto</td';
                            } 
                            else 
                            {
                                if (file_exists($ubicacion . chop($key->pathFoto))) 
                                {
                                    echo "<td><img src=".$ubicacion . chop($key->pathFoto) . " height='100px' width='100px'></td>";
                                } 
                                else
                                    echo '<td>SinFoto</td';
                            }
                            ?>
                        </tr>
                    <?php } ?>
                    <tr>
                        <td colspan="4">
                            <hr />
                        </td>
                    </tr>
                </table>
            </body>
            </html>
    <?php }
    } 
    else 
    {
        $receta = json_decode($receta);
        $obj = new stdClass();
        
        if ($accion == "borrar")
        {
            $obj->exito = false;
            $obj->mensaje = "La receta no se pudo eliminar de la base de datos";
            $auxFake = new Receta($receta->id, "", "", "");
            $lista = $auxFake->Traer();
            $auxBorrar = null;
            
            foreach ($lista as $key)
            {
                if ($key->id == $auxFake->id)
                {
                    $auxBorrar = new Receta($key->id, $key->nombre, $key->ingredientes, $key->tipo, $key->pathFoto);
                    break;
                }
            }
            
            
            if ($auxBorrar->Eliminar())
            {
                $obj->exito = true;
                $obj->mensaje = "La receta se elimino de la clase y se guardo en recetas_borradas";
                $auxBorrar->GuardarEnArchivo();
            }
            echo json_encode($obj);
        }
    }