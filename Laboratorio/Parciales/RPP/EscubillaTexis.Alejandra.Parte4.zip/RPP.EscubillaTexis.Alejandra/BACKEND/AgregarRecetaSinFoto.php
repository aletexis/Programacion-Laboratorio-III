<?php
    require "./clases/Receta.php";

    $nombre = $_POST["nombre"]??NULL;
    $ingredientes = $_POST["ingredientes"]??NULL;
    $tipo = $_POST["tipo"]??NULL;

    $sinFoto = new Receta("",$nombre,$ingredientes,$tipo);

    $obj = new stdClass();

    if($sinFoto->Agregar())
    {
        $obj->exito = true;
        $obj->mensaje = "La receta se agrego correctamente";
    }
    else
    {
        $obj->exito = false;
        $obj->mensaje = "La receta no fue agregada";
    }
    echo json_encode($obj);
?>