/// <reference path="../node_modules/@types/jquery/index.d.ts" />

$(function(){

    $('#usuarios').on('click', ObtenerListadoUsuarios);
    $('#autos').on('click', ObtenerListadoAutos);
    

    $('#altaAuto').on('click', function(){
        $('#izquierda').html(MostrarFormulario('alta'));
    });

    $('#logout').on('click', Logout);
});

function ObtenerListadoUsuarios() : void
{
    $("#derecha").html("");
    let token = localStorage.getItem("token");

    $.ajax({
        type: 'GET',
        url: API + "public/",
        dataType: "json",
        data: {},
        headers : {token : token},
        async: true
    })
    .done(function (resultado:any) {
        console.log(resultado);
        if(resultado.exito)
        {
            $("#derecha").html(ArmarTablaUsuarios(resultado.dato));
        }
    })
    .fail(function (jqXHR: any, textStatus: any, errorThrown: any)
    {
        let respuesta = JSON.parse(jqXHR.responseText);
        console.log(respuesta.mensaje);
    })
}

function ArmarTablaUsuarios(usuarios : any)
{
    let tabla:string = '<table class="table-responsive table table-dark table-hover rounded">';
    tabla += `<tr>
        <th>Id</th>
        <th>Correo</th>
        <th>Clave</th>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Perfil</th>
        <th>Foto</th>
    </tr>`;
    usuarios.forEach((usuario: { id: any; correo: any; clave: any; nombre: any; apellido: any; perfil: any; foto: any; }) => {

        tabla += `<tr>
        <td>${usuario.id}</td>
        <td>${usuario.correo}</td>
        <td>${usuario.clave}</td>
        <td>${usuario.nombre}</td>
        <td>${usuario.apellido}</td>
        <td>${usuario.perfil}</td>
        <td><img src="${usuario.foto}" alt="" width="50px" height="50px"></td>
        </tr>`;
    });
    tabla += "</table>";
    return tabla;
}

function ObtenerListadoAutos() : void
{
    $("#izquierda").html("");
    let token = localStorage.getItem("token");

    $.ajax({
        type: 'GET',
        url: API + 'public/autos',
        dataType: "json",
        data: {},
        headers : {token : token},
        async: true
    })
    .done(function (resultado:any)
    {
        console.log(resultado);
        if(resultado.exito)
        {
            if(resultado.dato === null)
            {
                $("#izquierda").html(CrearAlerta(resultado.mensaje, 'warning'));
            }
            else
            {
                $("#izquierda").html(ArmarTablaAutos(resultado.dato));
                $('[data-action="eliminar"]').on('click', function (e) {

                    let obj_auto_string = $(this).attr("data-obj_auto") as any;
                    let auto = JSON.parse(obj_auto_string);
                    console.log(auto);
                    if(confirm(`¿Desea borrar el auto marca ${auto.marca} de color ${auto.color} modelo ${auto.modelo}?`))
                    {
                        EliminarAuto(auto.id);
                    }
                });

                $('[data-action="modificar"]').on('click', function (e) {

                    let obj_auto_string = $(this).attr("data-obj_auto") as any;
                    let auto = JSON.parse(obj_auto_string);
                    console.log(auto);
                    $("#izquierda").html(MostrarFormulario('modificar', auto));
                });
            }
        }
    })
    .fail(function (jqXHR: any, textStatus: any, errorThrown: any)
    {
        let respuesta = JSON.parse(jqXHR.responseText);
        console.log(respuesta.mensaje);
    })
}

function ArmarTablaAutos(autos : any)
{
    let tabla:string = '<table class="table-responsive table table-dark table-hover rounded">';
    tabla += `<tr>
        <th>Marca</th>
        <th>Color</th>
        <th>Modelo</th>
        <th>Precio</th>
        <th>Eliminar</th>
        <th>Modificar</th>
    </tr>`;
    autos.forEach((auto: { marca: any; color: any; modelo: any; precio: any; }) => {

        tabla += `<tr>
        <td>${auto.marca}</td>
        <td>${auto.color}</td>
        <td>${auto.modelo}</td>
        <td>${auto.precio}</td>
        <td><a href='#' class='btn btn-danger' data-action='eliminar' data-obj_auto='${JSON.stringify(auto)}' title='Eliminar'>Eliminar</a></td>
        <td><a href='#' class='btn btn-info' data-action='modificar' data-obj_auto='${JSON.stringify(auto)}' title='Modificar'>Modificar</a></td>
        </tr>`;
    });
    tabla += "</table>";
    return tabla;
}

function EliminarAuto(id : string)
{
    VerificarJWT();
    let token = localStorage.getItem("token");

    $.ajax({
        type: 'DELETE',
        url: API + "public/cars/",
        dataType: "json",
        data: JSON.stringify({'id_auto' : id}),
        headers : {token : token,},
        async: true
    })
    .done(function (resultado:any) {
        if(resultado.exito)
        {
            ObtenerListadoAutos();
        }
        else
        {
            $("#error").html(CrearAlerta(resultado.mensaje, "warning"));
        }
    })
    .fail(function (jqXHR:any, textStatus:any, errorThrown:any) {
        let retorno = jqXHR.responseText;
        console.log(retorno);
    });       
}

function MostrarFormulario(accion:string, obj_auto:any=null):string 
{
    let boton = "";
    let funcion = "";

    switch (accion)
    {
        case "alta":
            boton = 'btnAgregar';
            funcion = 'AgregarAuto(event)';
            break;

        case "modificar":
            boton = 'btnModificar';
            funcion = 'ModificarAuto(event)';
            break;
    }

    let id = "";
    let color = "";
    let marca = "";
    let precio = "";
    let modelo = "";

    if (obj_auto !== null) 
    {
        id = obj_auto.id;
        color = obj_auto.color;
        marca = obj_auto.marca;
        precio = obj_auto.precio;
        modelo = obj_auto.modelo;       
    }

    let form:string = `<div class="row m-auto">
                            <div class="my-4">
                                <div class="p-3 rounded" style="background-color: darkcyan;">
                                    <form>
                                        <div class="form-group d-flex">
                                            <input type="hidden" class="form-control " id="id" value="${id}" readonly >
                                        </div>
                                        <div class="form-group d-flex">
                                            <i class="fas fa-trademark p-2 mr-2 content-center rounded border controlador bg-light"></i>
                                            <input type="text" class="form-control" id="marca" placeholder="Marca" name="marca" value="${marca}" required>
                                        </div>
                                        <div class="form-group d-flex">
                                            <i class="fas fa-palette p-2 mr-2 content-center rounded border controlador bg-light"></i>
                                            <input type="text" class="form-control" id="color" placeholder="Color" name="color" value="${color}"  required>
                                        </div>
                                        <div class="form-group d-flex">
                                            <i class="fas fa-dollar-sign p-2 mr-2 content-center rounded border controlador bg-light"></i>
                                            <input type="number" class="form-control" id="precio" placeholder="Precio" name="precio" value="${precio}" required>
                                        </div>
                                        <div class="form-group d-flex">
                                            <i class="fas fa-car p-2 mr-2 content-center rounded border controlador bg-light"></i>
                                            <input type="text" class="form-control" id="modelo" placeholder="Modelo" name="modelo" value="${modelo}" required>
                                        </div>
                                        <div class="row justify-content-around mt-3 mb-5">
                                            <button type="submit" id="${boton}" class="col-4 btn btn-success" onclick="${funcion}">Enviar</button>
                                            <button type="reset" class="col-4 btn btn-warning">Limpiar</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>`;
        return form;
}

function ModificarAuto(e : Event) : void 
{  
    VerificarJWT();
    e.preventDefault();
    let token = localStorage.getItem("token");
    let id = $("#id").val();
    let color = $("#color").val();
    let marca = $("#marca").val();
    let precio = $("#precio").val();
    let modelo = $("#modelo").val();
    
    let dato : any = {
        "color":color,
        "marca":marca,
        "precio":precio,
        "modelo":modelo
    };
    $.ajax({
        type: 'PUT',
        url: API + "public/cars/",
        dataType: "json",
        data: JSON.stringify({auto : dato, id_auto : id}),
        headers : {token : token, "content-type":"application/json"},
        async: true
    })
    .done(function (resultado:any) {
        if(resultado.exito)
        {
            $("#error").html(CrearAlerta(resultado.mensaje, "success"));
            ObtenerListadoAutos();
        }
        else
        {
            $("#error").html(CrearAlerta(resultado.mensaje, "warning"));
        }
    })
    .fail(function (jqXHR:any, textStatus:any, errorThrown:any) {
        let retorno = jqXHR.responseText;
        let alerta:string = CrearAlerta(retorno.mensaje, "warning");
        $("#error").html(alerta);
    });    
}

function AgregarAuto(e : Event) : void 
{  
    VerificarJWT();
    e.preventDefault();

    let color = $("#color").val();
    let marca = $("#marca").val();
    let precio = $("#precio").val();
    let modelo = $("#modelo").val();

    let datos : any = {
        "color":color,
        "marca":marca,
        "precio":precio,
        "modelo":modelo
    };

    $.ajax({
        type: 'POST',
        url: API + "public/",
        dataType: "json",
        data: {"auto":JSON.stringify(datos)},
        async: true
    })
    .done(function (resultado:any) {
        if(resultado.exito)
        {
            $("#error").html(CrearAlerta(resultado.mensaje, "success"));
        }
        else
        {
            $("#error").html(CrearAlerta(resultado.mensaje, "danger"));
        }
    })
    .fail(function (jqXHR:any, textStatus:any, errorThrown:any) {
        let retorno = JSON.stringify(jqXHR.responseText);
        let alerta:string = CrearAlerta(retorno, "danger");
        $("#error").html(alerta);
    });    
}

function VerificarJWT()
{
    let token:any = localStorage.getItem("token");

    $.ajax({
        type: 'GET',
        url: API + "public/login", 
        dataType: "json",
        data: {},
        headers : {"token":token},
        async: true

    })
    .done(function (resultado:any) {
        console.log(resultado);
        if(resultado.status == 403)
        {
            $(location).attr('href',API + "public/front-end-login");
        } 
    })
    .fail(function (jqXHR:any, textStatus:any, errorThrown:any) {
        let retorno = JSON.parse(jqXHR.responseText);
        console.log(retorno);
        alert("La sesion ha expirado, sera redirigido al login");
        location.href = "front-end-login";
    });
}

function CrearAlerta(mensaje : string, tipo : string = "success") : string
{
    let alerta : string = `<div class="alert alert-${tipo} alert-dismissible fade show" role="alert">
                            ${mensaje}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>`;
    return alerta;
}

function Logout():void 
{   
    localStorage.removeItem("token");
    $(location).attr('href',API + "public/front-end-login");
}