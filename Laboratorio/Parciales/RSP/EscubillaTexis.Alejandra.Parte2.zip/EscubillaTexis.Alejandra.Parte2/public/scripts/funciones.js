/// <reference path="../node_modules/@types/jquery/index.d.ts" />
var API = 'http://api_slim4/';
$(function () {
    $("#btnEnviar").on("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        var correo = $("#txtCorreo").val();
        var clave = $("#txtClave").val();
        var dato = {
            correo: correo,
            clave: clave
        };
        $.ajax({
            method: "POST",
            url: API + "public/login",
            dataType: "json",
            data: { user: JSON.stringify(dato) },
            async: true
        })
            .done(function (resultado) {
            if (resultado.exito) {
                localStorage.setItem("token", resultado.jwt);
                $(location).attr("href", API + "public/front-end-principal");
            }
            else {
                $(".alert").addClass("d-flex").removeClass("d-none");
                $(".alert p").html(resultado.mensaje);
            }
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
            $(".alert").addClass("d-flex").removeClass("d-none");
            $(".alert p").html("Error, verifique los datos ingresados");
        });
    });
    $(".close").click(function () {
        $(".alert").addClass("d-none").removeClass("d-flex");
    });
    $("#btnRegistro").click(function () {
        $(location).attr("href", API + "public/front-end-registro");
    });
});
/// <reference path="../node_modules/@types/jquery/index.d.ts" />
$(function () {
    $("#btnRegistrar").on("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        var token = localStorage.getItem("jwt");
        var foto = $("#foto").prop("files")[0];
        var correo = $("#txtCorreo").val();
        var clave = $("#txtClave").val();
        var nombre = $("#txtNombre").val();
        var apellido = $("#txtApellido").val();
        var perfil = $("#dpPerfil").val();
        var dato = {
            "correo": correo,
            "clave": clave,
            "nombre": nombre,
            "apellido": apellido,
            "perfil": perfil
        };
        var form = new FormData();
        var usuario = JSON.stringify(dato);
        form.append("usuario", usuario);
        form.append("foto", foto);
        $.ajax({
            method: "POST",
            url: API + "public/usuarios",
            dataType: "json",
            data: form,
            headers: { token: token },
            async: true,
            contentType: false,
            processData: false
        })
            .done(function (resultado) {
            if (resultado.exito) {
                $(location).attr("href", API + "public/front-end-login");
            }
            else {
                $(".alert").addClass("d-flex").removeClass("d-none");
                $(".alert p").html(resultado.mensaje);
            }
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
            $(".alert").addClass("d-flex").removeClass("d-none");
            $(".alert p").html("Error, verifique los datos ingresados");
        });
    });
    $(".close").click(function () {
        $(".alert").addClass("d-none").removeClass("d-flex");
    });
});
/// <reference path="../node_modules/@types/jquery/index.d.ts" />
$(function () {
    $('#usuarios').on('click', ObtenerListadoUsuarios);
    $('#autos').on('click', ObtenerListadoAutos);
    $('#altaAuto').on('click', function () {
        $('#izquierda').html(MostrarFormulario('alta'));
    });
    $('#logout').on('click', Logout);
});
function ObtenerListadoUsuarios() {
    $("#derecha").html("");
    var token = localStorage.getItem("token");
    $.ajax({
        type: 'GET',
        url: API + "public/",
        dataType: "json",
        data: {},
        headers: { token: token },
        async: true
    })
        .done(function (resultado) {
        console.log(resultado);
        if (resultado.exito) {
            $("#derecha").html(ArmarTablaUsuarios(resultado.dato));
        }
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        var respuesta = JSON.parse(jqXHR.responseText);
        console.log(respuesta.mensaje);
    });
}
function ArmarTablaUsuarios(usuarios) {
    var tabla = '<table class="table-responsive table table-dark table-hover rounded">';
    tabla += "<tr>\n        <th>Id</th>\n        <th>Correo</th>\n        <th>Clave</th>\n        <th>Nombre</th>\n        <th>Apellido</th>\n        <th>Perfil</th>\n        <th>Foto</th>\n    </tr>";
    usuarios.forEach(function (usuario) {
        tabla += "<tr>\n        <td>" + usuario.id + "</td>\n        <td>" + usuario.correo + "</td>\n        <td>" + usuario.clave + "</td>\n        <td>" + usuario.nombre + "</td>\n        <td>" + usuario.apellido + "</td>\n        <td>" + usuario.perfil + "</td>\n        <td><img src=\"" + usuario.foto + "\" alt=\"\" width=\"50px\" height=\"50px\"></td>\n        </tr>";
    });
    tabla += "</table>";
    return tabla;
}
function ObtenerListadoAutos() {
    $("#izquierda").html("");
    var token = localStorage.getItem("token");
    $.ajax({
        type: 'GET',
        url: API + 'public/autos',
        dataType: "json",
        data: {},
        headers: { token: token },
        async: true
    })
        .done(function (resultado) {
        console.log(resultado);
        if (resultado.exito) {
            if (resultado.dato === null) {
                $("#izquierda").html(CrearAlerta(resultado.mensaje, 'warning'));
            }
            else {
                $("#izquierda").html(ArmarTablaAutos(resultado.dato));
                $('[data-action="eliminar"]').on('click', function (e) {
                    var obj_auto_string = $(this).attr("data-obj_auto");
                    var auto = JSON.parse(obj_auto_string);
                    console.log(auto);
                    if (confirm("\u00BFDesea borrar el auto marca " + auto.marca + " de color " + auto.color + " modelo " + auto.modelo + "?")) {
                        EliminarAuto(auto.id);
                    }
                });
                $('[data-action="modificar"]').on('click', function (e) {
                    var obj_auto_string = $(this).attr("data-obj_auto");
                    var auto = JSON.parse(obj_auto_string);
                    console.log(auto);
                    $("#izquierda").html(MostrarFormulario('modificar', auto));
                });
            }
        }
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        var respuesta = JSON.parse(jqXHR.responseText);
        console.log(respuesta.mensaje);
    });
}
function ArmarTablaAutos(autos) {
    var tabla = '<table class="table-responsive table table-dark table-hover rounded">';
    tabla += "<tr>\n        <th>Marca</th>\n        <th>Color</th>\n        <th>Modelo</th>\n        <th>Precio</th>\n        <th>Eliminar</th>\n        <th>Modificar</th>\n    </tr>";
    autos.forEach(function (auto) {
        tabla += "<tr>\n        <td>" + auto.marca + "</td>\n        <td>" + auto.color + "</td>\n        <td>" + auto.modelo + "</td>\n        <td>" + auto.precio + "</td>\n        <td><a href='#' class='btn btn-danger' data-action='eliminar' data-obj_auto='" + JSON.stringify(auto) + "' title='Eliminar'>Eliminar</a></td>\n        <td><a href='#' class='btn btn-info' data-action='modificar' data-obj_auto='" + JSON.stringify(auto) + "' title='Modificar'>Modificar</a></td>\n        </tr>";
    });
    tabla += "</table>";
    return tabla;
}
function EliminarAuto(id) {
    VerificarJWT();
    var token = localStorage.getItem("token");
    $.ajax({
        type: 'DELETE',
        url: API + "public/cars/",
        dataType: "json",
        data: JSON.stringify({ 'id_auto': id }),
        headers: { token: token },
        async: true
    })
        .done(function (resultado) {
        if (resultado.exito) {
            ObtenerListadoAutos();
        }
        else {
            $("#error").html(CrearAlerta(resultado.mensaje, "warning"));
        }
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        var retorno = jqXHR.responseText;
        console.log(retorno);
    });
}
function MostrarFormulario(accion, obj_auto) {
    if (obj_auto === void 0) { obj_auto = null; }
    var boton = "";
    var funcion = "";
    switch (accion) {
        case "alta":
            boton = 'btnAgregar';
            funcion = 'AgregarAuto(event)';
            break;
        case "modificar":
            boton = 'btnModificar';
            funcion = 'ModificarAuto(event)';
            break;
    }
    var id = "";
    var color = "";
    var marca = "";
    var precio = "";
    var modelo = "";
    if (obj_auto !== null) {
        id = obj_auto.id;
        color = obj_auto.color;
        marca = obj_auto.marca;
        precio = obj_auto.precio;
        modelo = obj_auto.modelo;
    }
    var form = "<div class=\"row m-auto\">\n                            <div class=\"my-4\">\n                                <div class=\"p-3 rounded\" style=\"background-color: darkcyan;\">\n                                    <form>\n                                        <div class=\"form-group d-flex\">\n                                            <input type=\"hidden\" class=\"form-control \" id=\"id\" value=\"" + id + "\" readonly >\n                                        </div>\n                                        <div class=\"form-group d-flex\">\n                                            <i class=\"fas fa-trademark p-2 mr-2 content-center rounded border controlador bg-light\"></i>\n                                            <input type=\"text\" class=\"form-control\" id=\"marca\" placeholder=\"Marca\" name=\"marca\" value=\"" + marca + "\" required>\n                                        </div>\n                                        <div class=\"form-group d-flex\">\n                                            <i class=\"fas fa-palette p-2 mr-2 content-center rounded border controlador bg-light\"></i>\n                                            <input type=\"text\" class=\"form-control\" id=\"color\" placeholder=\"Color\" name=\"color\" value=\"" + color + "\"  required>\n                                        </div>\n                                        <div class=\"form-group d-flex\">\n                                            <i class=\"fas fa-dollar-sign p-2 mr-2 content-center rounded border controlador bg-light\"></i>\n                                            <input type=\"number\" class=\"form-control\" id=\"precio\" placeholder=\"Precio\" name=\"precio\" value=\"" + precio + "\" required>\n                                        </div>\n                                        <div class=\"form-group d-flex\">\n                                            <i class=\"fas fa-car p-2 mr-2 content-center rounded border controlador bg-light\"></i>\n                                            <input type=\"text\" class=\"form-control\" id=\"modelo\" placeholder=\"Modelo\" name=\"modelo\" value=\"" + modelo + "\" required>\n                                        </div>\n                                        <div class=\"row justify-content-around mt-3 mb-5\">\n                                            <button type=\"submit\" id=\"" + boton + "\" class=\"col-4 btn btn-success\" onclick=\"" + funcion + "\">Enviar</button>\n                                            <button type=\"reset\" class=\"col-4 btn btn-warning\">Limpiar</button>\n                                        </div>\n                                    </form>\n                                </div>\n                            </div>\n                        </div>";
    return form;
}
function ModificarAuto(e) {
    VerificarJWT();
    e.preventDefault();
    var token = localStorage.getItem("token");
    var id = $("#id").val();
    var color = $("#color").val();
    var marca = $("#marca").val();
    var precio = $("#precio").val();
    var modelo = $("#modelo").val();
    var dato = {
        "color": color,
        "marca": marca,
        "precio": precio,
        "modelo": modelo
    };
    $.ajax({
        type: 'PUT',
        url: API + "public/cars/",
        dataType: "json",
        data: JSON.stringify({ auto: dato, id_auto: id }),
        headers: { token: token, "content-type": "application/json" },
        async: true
    })
        .done(function (resultado) {
        if (resultado.exito) {
            $("#error").html(CrearAlerta(resultado.mensaje, "success"));
            ObtenerListadoAutos();
        }
        else {
            $("#error").html(CrearAlerta(resultado.mensaje, "warning"));
        }
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        var retorno = jqXHR.responseText;
        var alerta = CrearAlerta(retorno.mensaje, "warning");
        $("#error").html(alerta);
    });
}
function AgregarAuto(e) {
    VerificarJWT();
    e.preventDefault();
    var color = $("#color").val();
    var marca = $("#marca").val();
    var precio = $("#precio").val();
    var modelo = $("#modelo").val();
    var datos = {
        "color": color,
        "marca": marca,
        "precio": precio,
        "modelo": modelo
    };
    $.ajax({
        type: 'POST',
        url: API + "public/",
        dataType: "json",
        data: { "auto": JSON.stringify(datos) },
        async: true
    })
        .done(function (resultado) {
        if (resultado.exito) {
            $("#error").html(CrearAlerta(resultado.mensaje, "success"));
        }
        else {
            $("#error").html(CrearAlerta(resultado.mensaje, "danger"));
        }
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        var retorno = JSON.stringify(jqXHR.responseText);
        var alerta = CrearAlerta(retorno, "danger");
        $("#error").html(alerta);
    });
}
function VerificarJWT() {
    var token = localStorage.getItem("token");
    $.ajax({
        type: 'GET',
        url: API + "public/login",
        dataType: "json",
        data: {},
        headers: { "token": token },
        async: true
    })
        .done(function (resultado) {
        console.log(resultado);
        if (resultado.status == 403) {
            $(location).attr('href', API + "public/front-end-login");
        }
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        var retorno = JSON.parse(jqXHR.responseText);
        console.log(retorno);
        alert("La sesion ha expirado, sera redirigido al login");
        location.href = "front-end-login";
    });
}
function CrearAlerta(mensaje, tipo) {
    if (tipo === void 0) { tipo = "success"; }
    var alerta = "<div class=\"alert alert-" + tipo + " alert-dismissible fade show\" role=\"alert\">\n                            " + mensaje + "\n                            <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n                            <span aria-hidden=\"true\">&times;</span>\n                            </button>\n                        </div>";
    return alerta;
}
function Logout() {
    localStorage.removeItem("token");
    $(location).attr('href', API + "public/front-end-login");
}
